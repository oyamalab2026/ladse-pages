/* NSGA-II routine (implementation of the 'main' function) */

# include <stdio.h>
# include <stdlib.h>
# include <math.h>

# include "nsga2r.h"                                // MSS : �w�b�_�t�@�C���̕ύX
# include "rand.h"

int nreal;
int nbin;
int nobj;
int ncon;
int popsize;
double pcross_real;
double pcross_bin;
double pmut_real;
double pmut_bin;
double eta_c;
double eta_m;
int ngen;
int nbinmut;
int nrealmut;
int nbincross;
int nrealcross;
int *nbits;
double *min_realvar;
double *max_realvar;
double *min_binvar;
double *max_binvar;
int bitlength;

int nsga2(nsga2_init_t* nsga2_init, init_data_t* init_data) // MSS : �ʏ�̊֐��֕ύX
{
    int i;
    FILE *fpt1;
    FILE *fpt2;
    FILE *fpt3;
    FILE *fpt4;
    FILE *fpt5;
    population *parent_pop;
    population *child_pop;
    population *mixed_pop;
#ifdef MSS
    char fileInit[NAME_SIZE] = {0};     // initial_pop.out
    char fileFinal[NAME_SIZE] = {0};    // final_pop.out
    char fileBest[NAME_SIZE] = {0};     // best_pop.out
    char fileAll[NAME_SIZE] = {0};      // all_pop.out
    char fileParams[NAME_SIZE] = {0};   // params.out

    /* oos.h�̃O���[�o���ϐ��̐ݒ� */
    nowGeneration = 1;
    nowPopulation = 0;

    /* NSGA2�o�̓t�@�C����Output�t�H���_�����ɍ쐬���� */
    sprintf(fileInit, "output\\%s_%s\\initial_pop.out", init_data->caseName, init_data->time);
    sprintf(fileFinal, "output\\%s_%s\\final_pop.out", init_data->caseName, init_data->time);
    sprintf(fileBest, "output\\%s_%s\\best_pop.out", init_data->caseName, init_data->time);
    sprintf(fileAll, "output\\%s_%s\\all_pop.out", init_data->caseName, init_data->time);
    sprintf(fileParams, "output\\%s_%s\\params.out", init_data->caseName, init_data->time);
#else
    if (argc<2)
    {
        printf("\n Usage ./nsga2r random_seed \n");
        exit(1);
    }
#endif
    seed = nsga2_init->seed;        // MSS : �t�@�C���Ǎ��݂���\���̓Ǎ��݂ɕύX
    if (seed<=0.0 || seed>=1.0)
    {
        printf("\n Entered seed value is wrong, seed value must be in (0,1) \n");
        exit(1);
    }
    fpt1 = fopen(fileInit,"w");                     // MSS : �t�@�C������ύX
    fpt2 = fopen(fileFinal,"w");                    // MSS : �t�@�C������ύX
    fpt3 = fopen(fileBest,"w");                     // MSS : �t�@�C������ύX
    fpt4 = fopen(fileAll,"w");                      // MSS : �t�@�C������ύX
    fpt5 = fopen(fileParams,"w");                   // MSS : �t�@�C������ύX
    fprintf(fpt1,"# This file contains the data of initial population\n");
    fprintf(fpt2,"# This file contains the data of final population\n");
    fprintf(fpt3,"# This file contains the data of final feasible population (if found)\n");
    fprintf(fpt4,"# This file contains the data of all generations\n");
    fprintf(fpt5,"# This file contains information about inputs as read by the program\n");
    printf("\n Enter the problem relevant and algorithm relevant parameters ... ");
    popsize = (int)nsga2_init->popsize;             // MSS : 'scanf'����\���̓Ǎ��݂ɕύX
    if (popsize<4 || (popsize%4)!= 0)
    {
        printf("\n population size read is : %d",popsize);
        printf("\n Wrong population size entered, hence exiting \n");
        exit (1);
    }
    ngen = (int)nsga2_init->ngen;                   // MSS : 'scanf'����\���̓Ǎ��݂ɕύX
    if (ngen<1)
    {
        printf("\n number of generations read is : %d",ngen);
        printf("\n Wrong nuber of generations entered, hence exiting \n");
        exit (1);
    }
    nobj = nsga2_init->nobj;                        // MSS : 'scanf'����\���̓Ǎ��݂ɕύX
    if (nobj<1)
    {
        printf("\n number of objectives entered is : %d",nobj);
        printf("\n Wrong number of objectives entered, hence exiting \n");
        exit (1);
    }
    ncon = nsga2_init->ncon;                        // MSS : 'scanf'����\���̓Ǎ��݂ɕύX
    if (ncon<0)
    {
        printf("\n number of constraints entered is : %d",ncon);
        printf("\n Wrong number of constraints enetered, hence exiting \n");
        exit (1);
    }
    nreal = nsga2_init->nreal;                      // MSS : 'scanf'����\���̓Ǎ��݂ɕύX
    if (nreal<0)
    {
        printf("\n number of real variables entered is : %d",nreal);
        printf("\n Wrong number of variables entered, hence exiting \n");
        exit (1);
    }
    if (nreal != 0)
    {
        min_realvar = (double *)malloc(nreal*sizeof(double));
        max_realvar = (double *)malloc(nreal*sizeof(double));
        for (i=0; i<nreal; i++)
        {
            min_realvar[i] = nsga2_init->min_realvar[i];// MSS : 'scanf'����\���̓Ǎ��݂ɕύX
            max_realvar[i] = nsga2_init->max_realvar[i];// MSS : 'scanf'����\���̓Ǎ��݂ɕύX
            if (max_realvar[i] <= min_realvar[i])
            {
                printf("\n Wrong limits entered for the min and max bounds of real variable, hence exiting \n");
                exit(1);
            }
        }
        pcross_real = nsga2_init->pcross_real;      // MSS : 'scanf'����\���̓Ǎ��݂ɕύX
        if (pcross_real<0.0 || pcross_real>1.0)
        {
            printf("\n Probability of crossover entered is : %e",pcross_real);
            printf("\n Entered value of probability of crossover of real variables is out of bounds, hence exiting \n");
            exit (1);
        }
        pmut_real = nsga2_init->pmut_real;          // MSS : 'scanf'����\���̓Ǎ��݂ɕύX
        if (pmut_real<0.0 || pmut_real>1.0)
        {
            printf("\n Probability of mutation entered is : %e",pmut_real);
            printf("\n Entered value of probability of mutation of real variables is out of bounds, hence exiting \n");
            exit (1);
        }
        eta_c = nsga2_init->eta_c;                  // MSS : 'scanf'����\���̓Ǎ��݂ɕύX
        if (eta_c<=0)
        {
            printf("\n The value entered is : %e",eta_c);
            printf("\n Wrong value of distribution index for crossover entered, hence exiting \n");
            exit (1);
        }
        eta_m = nsga2_init->eta_m;                  // MSS : 'scanf'����\���̓Ǎ��݂ɕύX
        if (eta_m<=0)
        {
            printf("\n The value entered is : %e",eta_m);
            printf("\n Wrong value of distribution index for mutation entered, hence exiting \n");
            exit (1);
        }
    }
    nbin = nsga2_init->nbin;                        // MSS : 'scanf'����\���̓Ǎ��݂ɕύX
    if (nbin<0)
    {
        printf ("\n number of binary variables entered is : %d",nbin);
        printf ("\n Wrong number of binary variables entered, hence exiting \n");
        exit(1);
    }
    if (nbin != 0)
    {
        nbits = (int *)malloc(nbin*sizeof(int));
        min_binvar = (double *)malloc(nbin*sizeof(double));
        max_binvar = (double *)malloc(nbin*sizeof(double));
        for (i=0; i<nbin; i++)
        {
            nbits[i] = nsga2_init->nbits[i];        // MSS : 'scanf'����\���̓Ǎ��݂ɕύX
            if (nbits[i] < 1)
            {
                printf("\n Wrong number of bits for binary variable entered, hence exiting");
                exit(1);
            }
            min_binvar[i] = nsga2_init->min_binvar[i];// MSS : 'scanf'����\���̓Ǎ��݂ɕύX
            max_binvar[i] = nsga2_init->max_binvar[i];// MSS : 'scanf'����\���̓Ǎ��݂ɕύX
            if (max_binvar[i] <= min_binvar[i])
            {
                printf("\n Wrong limits entered for the min and max bounds of binary variable entered, hence exiting \n");
                exit(1);
            }
        }
        pcross_bin = nsga2_init->pcross_bin;        // MSS : 'scanf'����\���̓Ǎ��݂ɕύX
        if (pcross_bin<0.0 || pcross_bin>1.0)
        {
            printf("\n Probability of crossover entered is : %e",pcross_bin);
            printf("\n Entered value of probability of crossover of binary variables is out of bounds, hence exiting \n");
            exit (1);
        }
        pmut_bin = nsga2_init->pmut_bin;            // MSS : 'scanf'����\���̓Ǎ��݂ɕύX
        if (pmut_bin<0.0 || pmut_bin>1.0)
        {
            printf("\n Probability of mutation entered is : %e",pmut_bin);
            printf("\n Entered value of probability  of mutation of binary variables is out of bounds, hence exiting \n");
            exit (1);
        }
    }
    if (nreal==0 && nbin==0)
    {
        printf("\n Number of real as well as binary variables, both are zero, hence exiting \n");
        exit(1);
    }
    printf("\n Input data successfully entered, now performing initialization \n");
    fprintf(fpt5,"\n Population size = %d",popsize);
    fprintf(fpt5,"\n Number of generations = %d",ngen);
    fprintf(fpt5,"\n Number of objective functions = %d",nobj);
    fprintf(fpt5,"\n Number of constraints = %d",ncon);
    fprintf(fpt5,"\n Number of real variables = %d",nreal);
    if (nreal!=0)
    {
        for (i=0; i<nreal; i++)
        {
            fprintf(fpt5,"\n Lower limit of real variable %d = %e",i+1,min_realvar[i]);
            fprintf(fpt5,"\n Upper limit of real variable %d = %e",i+1,max_realvar[i]);
        }
        fprintf(fpt5,"\n Probability of crossover of real variable = %e",pcross_real);
        fprintf(fpt5,"\n Probability of mutation of real variable = %e",pmut_real);
        fprintf(fpt5,"\n Distribution index for crossover = %e",eta_c);
        fprintf(fpt5,"\n Distribution index for mutation = %e",eta_m);
    }
    fprintf(fpt5,"\n Number of binary variables = %d",nbin);
    if (nbin!=0)
    {
        for (i=0; i<nbin; i++)
        {
            fprintf(fpt5,"\n Number of bits for binary variable %d = %d",i+1,nbits[i]);
            fprintf(fpt5,"\n Lower limit of binary variable %d = %e",i+1,min_binvar[i]);
            fprintf(fpt5,"\n Upper limit of binary variable %d = %e",i+1,max_binvar[i]);
        }
        fprintf(fpt5,"\n Probability of crossover of binary variable = %e",pcross_bin);
        fprintf(fpt5,"\n Probability of mutation of binary variable = %e",pmut_bin);
    }
    fprintf(fpt5,"\n Seed for random number generator = %e",seed);
    bitlength = 0;
    if (nbin!=0)
    {
        for (i=0; i<nbin; i++)
        {
            bitlength += nbits[i];
        }
    }
    fprintf(fpt1,"# of objectives = %d, # of constraints = %d, # of real_var = %d, # of bits of bin_var = %d, constr_violation, rank, crowding_distance\n",nobj,ncon,nreal,bitlength);
    fprintf(fpt2,"# of objectives = %d, # of constraints = %d, # of real_var = %d, # of bits of bin_var = %d, constr_violation, rank, crowding_distance\n",nobj,ncon,nreal,bitlength);
    fprintf(fpt3,"# of objectives = %d, # of constraints = %d, # of real_var = %d, # of bits of bin_var = %d, constr_violation, rank, crowding_distance\n",nobj,ncon,nreal,bitlength);
    fprintf(fpt4,"# of objectives = %d, # of constraints = %d, # of real_var = %d, # of bits of bin_var = %d, constr_violation, rank, crowding_distance\n",nobj,ncon,nreal,bitlength);
    nbinmut = 0;
    nrealmut = 0;
    nbincross = 0;
    nrealcross = 0;
    parent_pop = (population *)malloc(sizeof(population));
    child_pop = (population *)malloc(sizeof(population));
    mixed_pop = (population *)malloc(sizeof(population));
    allocate_memory_pop (parent_pop, popsize);
    allocate_memory_pop (child_pop, popsize);
    allocate_memory_pop (mixed_pop, 2*popsize);
#ifdef MSS                                  // MSS : ���X�^�[�g�@�\���������邽�߂ɕύX
    if (nsga2_init->restartMode == RESTART_NGEN){       // ���X�^�[�g���Angen����܂ōœK�����s���ꍇ
		if (readPopFile(nsga2_init, parent_pop) == OOS_NG){
            return OOS_NG;
        }
        randomize();
        selection (parent_pop, child_pop);          // ������W�c�̐���
        mutation_pop (child_pop);
        decode_pop(child_pop);
        evaluate_pop(child_pop);                    // �O���݌v�\�t�g�E�F�A���s
        merge (parent_pop, child_pop, mixed_pop);
        fill_nondominated_sort (mixed_pop, parent_pop);
    }else if (nsga2_init->restartMode == RESTART_RANK){     // ���X�^�[�g���A�����N�t���v�Z�̂ݍs���ꍇ
        if (readPopFileForRank(nsga2_init, parent_pop, RESTART_RANK_GETPOP) == OOS_NG){
            return OOS_NG;
        }
        assign_rank_and_crowding_distance (parent_pop);
        ngen = 1;
    } else {                                        // ���X�^�[�g���Ȃ��ꍇ
        randomize();
        initialize_pop (parent_pop);
        printf("\n Initialization done, now performing first generation");
        decode_pop(parent_pop);
        evaluate_pop (parent_pop);
        assign_rank_and_crowding_distance (parent_pop);
    }
#endif
    report_pop (parent_pop, fpt1);
    fprintf(fpt4,"# gen = 1\n");
    report_pop(parent_pop,fpt4);
    printf("\n gen = 1");
    fflush(stdout);
    fflush(fpt1);
    fflush(fpt2);
    fflush(fpt3);
    fflush(fpt4);
    fflush(fpt5);
    for (i=2; i<=ngen; i++)             // MSS : ���X�^�[�g���l�������ő僋�[�v��
    {
        nowGeneration = i;                          // MSS : oos.h�̃O���[�o���ɓK�p
        selection (parent_pop, child_pop);
        mutation_pop (child_pop);
        decode_pop(child_pop);
        evaluate_pop(child_pop);
        merge (parent_pop, child_pop, mixed_pop);
        fill_nondominated_sort (mixed_pop, parent_pop);
        /* Comment following three lines if information for all
        generations is not desired, it will speed up the execution */
        fprintf(fpt4,"# gen = %d\n",i);
        report_pop(parent_pop,fpt4);
        fflush(fpt4);
        printf("\n gen = %d",i);
        fflush(stdout);
    }
    printf("\n Generations finished, now reporting solutions");
    report_pop(parent_pop,fpt2);
    report_feasible(parent_pop,fpt3);
    if (nreal!=0)
    {
        fprintf(fpt5,"\n Number of crossover of real variable = %d",nrealcross);
        fprintf(fpt5,"\n Number of mutation of real variable = %d",nrealmut);
    }
    if (nbin!=0)
    {
        fprintf(fpt5,"\n Number of crossover of binary variable = %d",nbincross);
        fprintf(fpt5,"\n Number of mutation of binary variable = %d",nbinmut);
    }
    fflush(stdout);
    fflush(fpt1);
    fflush(fpt2);
    fflush(fpt3);
    fflush(fpt4);
    fflush(fpt5);
    fclose(fpt1);
    fclose(fpt2);
    fclose(fpt3);
    fclose(fpt4);
    fclose(fpt5);
    if (nreal!=0)
    {
        free (min_realvar);
        free (max_realvar);
    }
    if (nbin!=0)
    {
        free (min_binvar);
        free (max_binvar);
        free (nbits);
    }
    deallocate_memory_pop (parent_pop, popsize);
    deallocate_memory_pop (child_pop, popsize);
    deallocate_memory_pop (mixed_pop, 2*popsize);
    free (parent_pop);
    free (child_pop);
    free (mixed_pop);
    printf("\n Routine successfully exited \n");
    return (0);
}
