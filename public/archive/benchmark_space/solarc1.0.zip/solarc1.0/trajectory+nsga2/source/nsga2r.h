//******************************************************************************
//  FILE NAME     : nsga2r.h
//  FUNCTION      : NSGA-II�̃\�[�X�R�[�h�Ŏg�p����w�b�_�t�@�C��
//  DATE(ORG)     : 2010/02/16
//  PROGRAMMED    : �O�H�X�y�[�X�E�\�t�g�E�G�A�������
//------------------------------------------------------------------------------
//  REMARKS       :
//  MODIFIED      :
//******************************************************************************

#ifndef NSGA2R_H_
#define NSGA2R_H_

# include "oos.h"
# include "global.h"

#define MSS

/* nsga2r.c */
extern int readPopFile(const nsga2_init_t* nsga2_init, population *parent_pop);
extern int readPopFileForRank(nsga2_init_t* nsga2_init, population *pParent_pop, const int readFlag);

#endif /* NSGA2R_H_ */
