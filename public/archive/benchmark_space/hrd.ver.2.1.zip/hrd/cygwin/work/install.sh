#!/bin/sh

cd src_f90

g95 -o of.exe of.f90
g95 -o structure.exe structure.f90
g95 -o thrust.exe thrust.f90
g95 -o post.exe post.f90
g95 -o cea-frozen.exe cea-frozen.f90
g95 -o cea-inp2.exe cea-inp2.f90

mv of.exe ../
mv structure.exe ../
mv thrust.exe ../
mv post.exe ../
mv cea-frozen.exe ../
mv cea-inp2.exe ../

cd ../
