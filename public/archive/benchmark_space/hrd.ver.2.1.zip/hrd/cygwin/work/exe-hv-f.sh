#!/bin/sh
echo O/F Calculation
./of.exe
echo ..done

echo Structure Calculation
echo "hr-ini" > inp.txt
./FCEA2.exe < inp.txt
rm inp.txt
./structure.exe

echo cea-inp2
./cea-inp2.exe

echo mv files1
mv hr-ini.plt th-inp1.plt
mv m_dot-0000.dat th-inp2.dat
mv cea-inp2.dat th-inp3.dat
mv m_tot-0000.dat th-inp4.dat

echo thrust calculation
./thrust.exe

echo mv files2
rm th-inp1.plt th-inp2.dat th-inp3.dat th-inp4.dat
mv thrust.dat thrust0000.dat
mv tra.dat th-inp3.dat



echo iteration
i=1
while [ $i -le 9 ]
do
echo $i
mv of-000$i.dat cea-inp2.dat
./cea-frozen.exe
echo "th-inp1" > inp.txt
./FCEA2.exe < inp.txt
rm inp.txt

mv m_dot-000$i.dat th-inp2.dat
mv m_tot-000$i.dat th-inp4.dat

./thrust.exe

rm th-inp1.plt th-inp2.dat th-inp3.dat th-inp4.dat
mv thrust.dat thrust000$i.dat
mv tra.dat th-inp3.dat

i=`expr $i + 1`
done



i=10
while [ $i -le 99 ]
do
echo $i
mv of-00$i.dat cea-inp2.dat
./cea-frozen.exe
echo "th-inp1" > inp.txt
./FCEA2.exe < inp.txt
rm inp.txt

mv m_dot-00$i.dat th-inp2.dat
mv m_tot-00$i.dat th-inp4.dat

./thrust.exe

rm th-inp1.plt th-inp2.dat th-inp3.dat th-inp4.dat
mv thrust.dat thrust00$i.dat
mv tra.dat th-inp3.dat

i=`expr $i + 1`
done



i=100
while [ $i -le 999 ]
do
echo $i
mv of-0$i.dat cea-inp2.dat
./cea-frozen.exe
echo "th-inp1" > inp.txt
./FCEA2.exe < inp.txt
rm inp.txt

mv m_dot-0$i.dat th-inp2.dat
mv m_tot-0$i.dat th-inp4.dat

./thrust.exe

rm th-inp1.plt th-inp2.dat th-inp3.dat th-inp4.dat
mv thrust.dat thrust0$i.dat
mv tra.dat th-inp3.dat

i=`expr $i + 1`
done



i=1000
echo $i
mv of-$i.dat cea-inp2.dat
./cea-frozen.exe
echo "th-inp1" > inp.txt
./FCEA2.exe < inp.txt
rm inp.txt

mv m_dot-$i.dat th-inp2.dat
mv m_tot-$i.dat th-inp4.dat

./thrust.exe

rm th-inp1.plt th-inp2.dat th-inp3.dat th-inp4.dat
mv thrust.dat thrust$i.dat
mv tra.dat th-inp3.dat


./post.exe


rm thrust****.dat
rm cea-inp2.dat
rm engine-str-inp.dat
rm f-inp.dat
rm m_dot_ini.dat
rm m_prop.dat
rm th-inp3.dat
rm hr-ini.inp
rm hr-ini.out
rm th-inp1.inp
rm th-inp1.out


echo ..end
